package com.abdu.testapp

import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        //añadimos una variable nbombre button y de tipo Button
        // y asociamos esta variable al botón de la view
        val button: Button = findViewById(R.id.botonCentral)

        button.setOnClickListener {
            // método para que al pulsar el botón salga un mensaje emergente
            Toast.makeText(this, "Hola mundo, por 21239123 vez",Toast.LENGTH_SHORT).show()

        }
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }
}